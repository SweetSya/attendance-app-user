import vision from "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3";
const { FaceLandmarker, FilesetResolver, DrawingUtils } = vision;

let faceLandmarker;
let runningMode;
let webcamRunning;
let video;
let elemPitch;
let elemYaw;
let videoWrapper;
let canvasElement;
let canvasCtx;
let drawingUtils;
let animationFrameFace = null;

let capturedFrame;
let firstLaunch;
let lastVideoTime;
let results;
let initialFace;
let calibrateInitialFace;
let wasBlinking;

const filesetResolver = await FilesetResolver.forVisionTasks(
    "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.3/wasm"
);

const resizeCapturer = () => {
    const aspectRatio = video.videoHeight / video.videoWidth;
    video.style.width = videoWrapper.clientWidth + "px";
    video.style.height = videoWrapper.clientWidth * aspectRatio + "px";
    canvasElement.style.width = videoWrapper.clientWidth + "px";
    canvasElement.style.height = videoWrapper.clientWidth * aspectRatio + "px";
    canvasElement.width = videoWrapper.clientWidth;
    canvasElement.height = videoWrapper.clientHeight;
};

async function createFaceLandmarker() {
    faceLandmarker = await FaceLandmarker.createFromOptions(filesetResolver, {
        baseOptions: {
            modelAssetPath:
                "https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task",
            delegate: "GPU",
        },
        outputFaceBlendshapes: true,
        runningMode,
        numFaces: 1,
    });
    dispatchEvent(
        new CustomEvent("set_landmarker", {
            detail: {
                state: true,
            },
        })
    );
}
function setCalibrateInitialFace(state) {
    calibrateInitialFace = state;
}
function captureFrame(videoElement) {
    const canvas = document.createElement("canvas");
    canvas.width = videoElement.videoWidth;
    canvas.height = videoElement.videoHeight;

    const ctx = canvas.getContext("2d");
    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

    // This is base64 string: "data:image/png;base64,AAAA..."
    return canvas.toDataURL("image/png");
}
async function predictWebcam() {
    console.log("predict-webcam");
    resizeCapturer();
    if (runningMode === "IMAGE") {
        runningMode = "VIDEO";
        await faceLandmarker.setOptions({ runningMode });
    }

    let startTimeMs = performance.now();
    if (lastVideoTime !== video.currentTime) {
        lastVideoTime = video.currentTime;
        results = faceLandmarker.detectForVideo(video, startTimeMs);
    }

    canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);
    if (results.faceLandmarks) {
        if (results.faceLandmarks.length > 0) {
            const landmarks = results.faceLandmarks[0];

            const leftCheek = landmarks[234]; // Titik pipi kiri
            const rightCheek = landmarks[454]; // Titik pipi kanan
            const noseTip = landmarks[1];
            const chin = landmarks[152];
            const faceWidth = Math.hypot(
                rightCheek.x - leftCheek.x,
                rightCheek.y - leftCheek.y
            );
            const noseCenterX = (rightCheek.x + leftCheek.x) / 2;
            // Normalize offsets by face width
            const yaw = (noseTip.x - noseCenterX) / faceWidth;
            const pitch = (chin.y - noseTip.y) / faceWidth;
            // If user wanna calibrate
            if (calibrateInitialFace) {
                initialFace.pitch = pitch;
                initialFace.yaw = yaw;
                capturedFrame = {
                    "netral-netral": "",
                    "top-netral": "",
                    "bottom-netral": "",
                    "netral-right": "",
                    "netral-left": "",
                };
                dispatchEvent(
                    new CustomEvent("set_camera_capture", {
                        detail: {
                            images: capturedFrame,
                        },
                    })
                );
                calibrateInitialFace = false;
                sendNotfy.success("Kalibrasi kamera berhasil");
            }
            let direction = {
                x: "",
                y: "",
            };
            elemPitch.innerHTML = pitch.toFixed(4);
            elemYaw.innerHTML = yaw.toFixed(4);

            // Check direction Y
            if (pitch - initialFace.pitch > 0.11) {
                direction.y = "top";
            } else if (pitch - initialFace.pitch < -0.11) {
                direction.y = "bottom";
            } else {
                direction.y = "netral";
            }
            // Check direction X
            if (yaw - initialFace.yaw > 0.21) {
                direction.x = "left";
            } else if (yaw - initialFace.yaw < -0.21) {
                direction.x = "right";
            } else {
                direction.x = "netral";
            }
            if (initialFace.pitch || initialFace.yaw) {
                let currentDirection = `${direction.y}-${direction.x}`;
                if (currentDirection.includes(["buttom-right", "top-right"])) {
                    currentDirection = "netral-right";
                }
                if (currentDirection.includes(["buttom-left", "top-left"])) {
                    currentDirection = "netral-left";
                }
                if (currentDirection in capturedFrame) {
                    // Capture for each frame
                    if (
                        capturedFrame[currentDirection] == "" &&
                        !Object.values(capturedFrame).some(
                            (v) => v === "hold" || v === "changing"
                        )
                    ) {
                        capturedFrame[currentDirection] = "hold";
                        sendNotfy.open({
                            type: "info",
                            message: `Pertahankan posisi ${currentDirection} selama 2 detik`,
                        });
                        setTimeout(() => {
                            capturedFrame[currentDirection] = "capturing";
                        }, 2000);
                    }
                }
            }
            if (Object.values(capturedFrame).some((v) => v === "capturing")) {
                const directionKey = Object.entries(capturedFrame).find(
                    ([k, v]) => v === "capturing"
                )?.[0];
                capturedFrame[directionKey] = captureFrame(video);
                console.log(capturedFrame);
                dispatchEvent(
                    new CustomEvent("set_camera_capture", {
                        detail: {
                            images: capturedFrame,
                        },
                    })
                );
                sendNotfy.success("Berhasil menangkap muka");
                console.log(`Menghadap: ${directionKey}`);
                console.log("======================================");
        }
        }

        for (const landmarks of results.faceLandmarks) {
            // Outer face oval
            drawingUtils.drawConnectors(
                landmarks,
                FaceLandmarker.FACE_LANDMARKS_FACE_OVAL,
                { color: "#C0C0C0", lineWidth: 1.5 }
            );

            // Right eye
            drawingUtils.drawConnectors(
                landmarks,
                FaceLandmarker.FACE_LANDMARKS_RIGHT_EYE,
                { color: "#FF3030", lineWidth: 1 }
            );

            // Left eye
            drawingUtils.drawConnectors(
                landmarks,
                FaceLandmarker.FACE_LANDMARKS_LEFT_EYE,
                { color: "#30FF30", lineWidth: 1 }
            );
        }
    }

    drawBlendShapes(results.faceBlendshapes);

    if (webcamRunning) {
        animationFrameFace = window.requestAnimationFrame(predictWebcam);
        if (firstLaunch) {
            canvasElement.classList.remove("hidden");
            dispatchEvent(
                new CustomEvent("set_camera_status", {
                    detail: {
                        status: "running",
                    },
                })
            );
            firstLaunch = false;
        }
    }
}
function drawBlendShapes(blendShapes) {
    if (!blendShapes.length) return;

    const categories = blendShapes[0].categories;
    let html = "";
    let blink = {
        left: false,
        right: false,
    };
    categories.forEach((shape) => {
        const name = shape.displayName || shape.categoryName;
        const score = shape.score;

        if (name === "eyeBlinkLeft" && score > 0.4) {
            blink.left = true;
        }
        if (name === "eyeBlinkRight" && score > 0.6) {
            blink.right = true;
        }
        if (blink.right && blink.left && !wasBlinking) {
            wasBlinking = true;
            const allFilled = Object.values(capturedFrame).every(
                (value) => value !== ""
            );
            if (allFilled) {
                if (video.srcObject) {
                    video.removeEventListener("loadeddata", predictWebcam);
                    console.log("STOP VIDEO");
                    video.srcObject
                        .getTracks()
                        .forEach((track) => track.stop());
                    video.srcObject = null;
                    // Normalize everything soo it can run for the next scan if needed
                    dispatchEvent(
                        new CustomEvent("set_camera_status", {
                            detail: {
                                status: "offline",
                            },
                        })
                    );
                    sendNotfy.success("Berhasil menangkap muka");
                    canvasElement.classList.add("hidden");
                    firstLaunch = true;
                    webcamRunning = false;
                    runningMode = "IMAGE";
                }
                console.log(capturedFrame);
            } else {
                wasBlinking = false;
            }
        }
    });
}

async function requestUserCamera() {
    if (!faceLandmarker) return alert("Terjadi kesalahan pada Landmarker");
    try {
        const stream = await navigator.mediaDevices.getUserMedia({
            video: {
                facingMode: "user",
            },
        });
        capturedFrame = {
            "netral-netral": "",
            "top-netral": "",
            "bottom-netral": "",
            "netral-right": "",
            "netral-left": "",
        };
        dispatchEvent(
            new CustomEvent("set_camera_capture", {
                detail: {
                    images: capturedFrame,
                },
            })
        );
        wasBlinking = false;
        video.srcObject = stream;
        webcamRunning = true;
        video.addEventListener("loadeddata", predictWebcam);
        return {
            status: "preparing",
            message: "Mempersiapkan kamera",
        };
    } catch (error) {
        const errString = error.toString();
        if (errString.includes("dismissed")) {
            return {
                status: "error",
                message:
                    "Harap izinkan aplikasi untuk mengakses perangkat kamera",
            };
        } else if (errString.includes("denied")) {
            return {
                status: "error",
                message:
                    "Izin akses kamera terblokir, harap izinkan terlebih dahulu",
            };
        } else {
            return {
                status: "error",
                message:
                    "Terjadi kesalahan saat mengakses kamera: " + errString,
            };
        }
    }
}
const initBiometricFace = () => {
    if (video) {
        video.removeEventListener("loadeddata", predictWebcam);
    }
    runningMode = "IMAGE";
    webcamRunning = false;

    video = document.getElementById("webcam");
    elemPitch = document.getElementById("pitch");
    elemYaw = document.getElementById("yaw");
    videoWrapper = document.querySelector("#webcam-wrapper");
    canvasElement = document.getElementById("output_canvas");
    canvasCtx = canvasElement.getContext("2d");
    drawingUtils = new DrawingUtils(canvasCtx);
    animationFrameFace = null;

    capturedFrame = {
        "netral-netral": "",
        "top-netral": "",
        "bottom-netral": "",
        "netral-right": "",
        "netral-left": "",
    };

    dispatchEvent(
        new CustomEvent("set_camera_capture", {
            detail: {
                images: {},
            },
        })
    );
    firstLaunch = true;
    lastVideoTime = -1;
    results = undefined;
    initialFace = {
        pitch: null,
        yaw: null,
    };
    calibrateInitialFace = false;
    wasBlinking = false;

    createFaceLandmarker();
};

const removeAnimationFrame = () => {
    dispatchEvent(
        new CustomEvent("set_landmarker", {
            detail: {
                state: false,
            },
        })
    );
    video.removeEventListener("loadeddata", predictWebcam);
    cancelAnimationFrame(animationFrameFace);
    animationFrameFace = null;
    console.log("Animation Frame Removed");
};

window.removeAnimationFrame = removeAnimationFrame;
window.initBiometricFace = initBiometricFace;
window.createFaceLandmarker = createFaceLandmarker;
window.requestUserCamera = requestUserCamera;
window.setCalibrateInitialFace = setCalibrateInitialFace;
window.captureFrame = captureFrame;
